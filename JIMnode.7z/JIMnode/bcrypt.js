const bycrpt = require("bcryptjs");

console.log(bycrpt.hashSync("123456", 8));
