const mysql = require("mysql2");
const pool = mysql.createPool({
    host: "localhost", // 阜位
    user: "root", // 使用者
    password: "", // 密碼
    database: "kevin", // 連到哪個資料庫
    waitForConnections: true, // 等待連線
    connectionLimit: 5, // 最多可同時連線數(為省效能而設計的)
    queueLimit: 0, // 是否限定排隊人數，0是不限制
});
module.exports = pool.promise();
