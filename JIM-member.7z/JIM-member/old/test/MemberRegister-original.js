import { useState } from 'react'
import axios from 'axios'
import '../../style/JIM_Register.css'
import { ACCOUNTREGISTER } from '../../config/api_config'
import { useNavigate } from 'react-router-dom'

function MemberRegister() {
  const [memberRegisterInput, setMemberRegisterInput] = useState({
    mNickname: '',
    mAccount: '',
    mPassword: '',
    mName: '',
    mGender: '',
    mBirth: '',
    mEmail: '',
    mMobile: '',
    mIdentity: '',
  })

  const navigate = useNavigate()

   const sendMemberRegisterData = async () => {
    axios.defaults.withCredentials = true
    await axios.put(ACCOUNTREGISTER, memberRegisterInput).then((response) => {
      if (response.data.success) {
        alert('註冊成功')
        navigate('/memberLogin')
      }
    })
  }
  return (
    <>
      {/* <div className="m-bearBg"></div>
      <div className="m-blackBg"></div> */}
      <main className="m-memberRegisterMain">
        <div className="d-flex m-firstSection">
          <button className="m-loginChange btn">會員登入</button>
          <button className="m-signInChange btn">加入會員</button>
        </div>
        <div className="m-registerSecondSection">
          <div className="m-mainText">
            <h1>會員註冊</h1>
            <h4>SIGN UP</h4>
          </div>
          <div>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                sendMemberRegisterData()
              }}
            >
              <div>
                <div className="m-registerAccount">
                  <label htmlFor="mAccount">帳號：</label>
                  <input
                    type="text"
                    placeholder="請填寫帳號"
                    name="mAccount"
                    className="m-registerAccountInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mAccount: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerPassword">
                  <label htmlFor="mPassword">設定密碼：</label>
                  <input
                    type="text"
                    placeholder="請設定6-10位數英數字混和密碼，英文需區分大小寫"
                    name="mPassword"
                    className="m-registerPasswordInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mPassword: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerPasswordVerify">
                  <label htmlFor="mPasswordVerify">密碼確認：</label>
                  <input
                    type="text"
                    placeholder="請再輸入一次密碼"
                    name="mPasswordVerify"
                    className="m-registerPasswordVerifyInput"
                  />
                </div>
                <div className="m-registerRealName">
                  <label htmlFor="mName">姓名：</label>
                  <input
                    type="text"
                    placeholder="請填寫真實中文姓名"
                    name="mName"
                    className="m-registerRealNameInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mName: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerEmail">
                  <label htmlFor="mEmail">信箱：</label>
                  <input
                    type="text"
                    placeholder="請填寫Email"
                    name="mEmail"
                    className="m-registerEmailInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mEmail: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerMobile">
                  <label htmlFor="mMobile">手機：</label>
                  <input
                    type="text"
                    placeholder="請填寫手機號碼"
                    name="mMobile"
                    className="m-registerMobileInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mMobile: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerNickName">
                  <label htmlFor="mNickname">暱稱：</label>
                  <input
                    type="text"
                    placeholder="請填寫暱稱"
                    name="mNickname"
                    className="m-registerNickNameInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mNickname: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerGender">
                  <label>性別：</label>
                  <div className="m-registerGenderRadio">
                    <div>
                      <input
                        type="radio"
                        value="男"
                        name="mGender"
                        onChange={(e) => {
                          setMemberRegisterInput((prev) => ({
                            ...memberRegisterInput,
                            mGender: e.target.value,
                          }))
                        }}
                      />
                      <label htmlFor="mGender">男</label>
                    </div>
                    <div>
                      <input
                        type="radio"
                        value="女"
                        name="mGender"
                        onChange={(e) => {
                          setMemberRegisterInput((prev) => ({
                            ...memberRegisterInput,
                            mGender: e.target.value,
                          }))
                        }}
                      />
                      <label htmlFor="mGender">女</label>
                    </div>
                  </div>
                </div>
                <div className="m-registerBirth">
                  <label htmlFor="mBirth">生日：</label>
                  <input
                    type="date"
                    name="mBirth"
                    className="m-registerBirthInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mBirth: e.target.value,
                      }))
                    }}
                  />
                </div>
                <div className="m-registerIdentity">
                  <label htmlFor="mIdentity">身分證字號：</label>
                  <input
                    type="text"
                    placeholder="請填寫身分證字號"
                    name="mIdentity"
                    className="m-registerIdentityInput"
                    onChange={(e) => {
                      setMemberRegisterInput((prev) => ({
                        ...memberRegisterInput,
                        mIdentity: e.target.value,
                      }))
                    }}
                  />
                </div>
              </div>
              <div>
                <button className="m-registerSubmit">立即註冊</button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </>
  )
}

export default MemberRegister
