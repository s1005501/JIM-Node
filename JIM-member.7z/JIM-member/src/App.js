import './style/template.css'

import { BrowserRouter, Routes, Route, useSearchParams } from 'react-router-dom'
import Header from './components/common/Header'
import Footer from './components/common/Footer'
import Background from './components/common/Background'
import Firstplate from './components/common/Firstplate'
import MemberAccountOrder from './components/member/MemberAccountOrder'
import MemberAccountLike from './components/member/MemberAccountLike'
import MemberAccountComment from './components/member/MemberAccountComment'
import MemberAccountLevel from './components/member/MemberAccountLevel'
import MemberAccountProfile from './components/member/MemberAccountProfile'
import MemberLoginRegister from './components/member/MemberLoginRegister'
import { MemberAuthContextProvider } from './contexts/MemberAuthContext'

function App() {
  return (
    <>
      <BrowserRouter>
        <MemberAuthContextProvider>
          <Background>
            <Header />
            <Firstplate>
              <Routes>
                <Route path="/memberLogin" element={<MemberLoginRegister />} />
                <Route
                  path="/memberAccount/order"
                  element={<MemberAccountOrder />}
                />
                <Route
                  path="/memberAccount/like"
                  element={<MemberAccountLike />}
                />
                <Route
                  path="/memberAccount/comment"
                  element={<MemberAccountComment />}
                />
                <Route
                  path="/memberAccount/level"
                  element={<MemberAccountLevel />}
                />
                <Route
                  path="/memberAccount/profile"
                  element={<MemberAccountProfile />}
                />
              </Routes>
            </Firstplate>
            <Footer />
          </Background>
        </MemberAuthContextProvider>
      </BrowserRouter>
    </>
  )
}

// todo 更新個人資料燈箱????

export default App
// todo 表單自動填入無法手動輸入且無法判定有填入資料
