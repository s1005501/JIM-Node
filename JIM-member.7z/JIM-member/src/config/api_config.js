// node的port
export const HOST = 'http://localhost:3005'

// member登入
export const ACCOUNTLOGIN = `${HOST}/member/login`

// google登入
export const ACCOUNTGOOGLELOGIN = `${HOST}/member/googlelogin`

// member註冊
export const ACCOUNTREGISTER = `${HOST}/member/register`

// member的node路徑
export const ACCOUNT = `${HOST}/member`
