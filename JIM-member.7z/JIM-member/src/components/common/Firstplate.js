import React from 'react'
import { Link } from 'react-router-dom'

function Firstplate({ children }) {
  return (
    <>
      <div className="bodyContainer">
        <div className="mainContainer">{children}</div>
      </div>
    </>
  )
}

export default Firstplate
